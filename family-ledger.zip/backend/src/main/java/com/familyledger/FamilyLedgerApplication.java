package com.familyledger;

import com.familyledger.db.Seeder;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class FamilyLedgerApplication {

  public static void main(String[] args) {
    SpringApplication.run(FamilyLedgerApplication.class, args);
  }

  /** 启动即初始化种子数据（幂等）。 */
  @Bean
  CommandLineRunner seedOnStartup(Seeder seeder) {
    return args -> seeder.ensureSeeded();
  }
}
